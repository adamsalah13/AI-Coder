import sys
import subprocess
from coder import generate_code_with_ollama, clean_generated_code, run_generated_code

def ensure_libraries_installed():
    required_libraries = ["subprocess", "io", "contextlib", "traceback"]
    for lib in required_libraries:
        try:
            __import__(lib)
        except ImportError:
            response = input(f"The library '{lib}' is not installed. Do you want to install it? (yes/no): ")
            if response.lower() == 'yes':
                subprocess.check_call([sys.executable, "-m", "pip", "install", lib])
            else:
                print(f"Cannot proceed without installing '{lib}'. Exiting.")
                sys.exit(1)

class AgenticTool:
    def __init__(self, user_input):
        self.user_input = user_input
        self.generated_code = ""
        self.output = ""

    def generate_code(self):
        self.generated_code = generate_code_with_ollama(self.user_input)
        self.generated_code = clean_generated_code(self.generated_code)

    def run_code(self):
        self.output = run_generated_code(self.generated_code)
        return self.output

    def execute(self):
        self.generate_code()
        return self.run_code()

# Example usage:
if __name__ == "__main__":
    ensure_libraries_installed()
    
    if len(sys.argv) > 1:
        user_input = ' '.join(sys.argv[1:])
    else:
        user_input = input("Enter the task description: ")
    
    tool = AgenticTool(user_input)
    result = tool.execute()
    print("Agentic Tool output:")
    print(result)
